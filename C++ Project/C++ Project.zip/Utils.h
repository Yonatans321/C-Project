#pragma once

void gotoxy(int x, int y);

void hideCursor();

void cls();

void setScreen(int width, int height);

void setColor(int color);

void clearInputBuffer();