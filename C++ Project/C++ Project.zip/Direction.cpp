//Taken from lab materials
#include "Direction.h"

const Direction Direction::directions[] = {
		{0, -1},
		{1, 0},
		{0, 1},
		{-1, 0},
		{0, 0}
};

