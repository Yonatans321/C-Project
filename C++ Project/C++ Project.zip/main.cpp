#include "Game.h"
#include <iostream> 


int main() {
    

    Game game;
    game.run(); 
    return 0;
}